package com.example.testapplication.activity

import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import android.widget.GridView
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import com.example.testapplication.R
import com.example.testapplication.Utility.isTablet
import com.example.testapplication.adapter.MainAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var gridView: GridView
    lateinit var mainAdapter: MainAdapter
    private var playerNames = arrayOf(
        "cristiano", "joao", "silva", "andre", "bruno", "william", "nelson",
        "pepe", "rui", "jo", "sil", "andr", "bruno", "william"
    )
    private var playerList = playerNames.toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadGridView()
        initSearch()
    }

    private fun initSearch() {
        val searchView : SearchView = findViewById(R.id.svSearch)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                search(newText)
                return false
            }
        })
    }

    private fun search(searchText: String) {
        playerList.clear()
        playerNames.iterator().forEach {
            if(it.contains(searchText)){
                playerList.add(it)
            }
        }
        mainAdapter.notifyDataSetChanged()
    }

    private fun loadGridView() {
        gridView = findViewById(R.id.gvGridView)
        if (isTablet())
            gridView.numColumns = 7
        else
            gridView.numColumns = 3

        mainAdapter = MainAdapter(this@MainActivity, playerList)
        gridView.adapter = mainAdapter
        gridView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            startActivity(Intent(this, DetailActivity::class.java))
        }
    }


}